<!DOCTYPE html>
<html lang="en">
<head>

     <title><?php echo $compPublicName; ?></title>


     
     
     
     


     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="Tooplate">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
				
     <link rel="stylesheet" href=<?php echo base_url("/css/bootstrap.min.css"); ?>  >
     <link rel="stylesheet" href=<?php echo base_url("/css/font-awesome.min.css"); ?>      >
     <link rel="stylesheet" href=<?php echo base_url("/css/animate.css"); ?>     >
     <link rel="stylesheet" href=<?php echo base_url("/css/owl.carousel.css"); ?>      >
     <link rel="stylesheet" href=<?php echo base_url("/css/owl.theme.default.min.css"); ?>     >

     <!-- MAIN CSS -->
     <link rel="stylesheet" href=<?php echo base_url("/css/tooplate-style.css"); ?>     >

     <!--link href="style.css" rel="stylesheet" type="text/css"-->
     <link rel="stylesheet"  href=<?php echo base_url("/css/calendar.css"); ?>   type="text/css">

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- HEADER -->
     <header>
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-5">
                         <p>Welcome to <?php echo $compPublicName; ?></p>
                    </div>
                         
                    <div class="col-md-8 col-sm-7 text-align-right">



		

                         
                         <span class="date-icon"><i class="fa fa-calendar-plus-o"></i> <?php echo $compWorkingHrs; ?></span>
                         <span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#"><?php echo $compEmail; ?></a></span>


		<?php if (isset($_SESSION['logedin']))
               { ?>

		    <span class="sgn-icon"><i class="fa fa-envelop-o"></i> <a href=<?php echo base_url("/home/org_public_web/frabi/chngInfo"); ?>#register>My Info</a></span>
		    <span class="sgn-icon"><i class="fa fa-envelop-o"></i> <a href=<?php echo base_url("/home/org_public_web/frabi/appointments"); ?>  >My Appointments</a></span>
                    <span class="sgn-icon"><i class="fa fa-envelop-o"></i> <a href=<?php echo base_url("/home/logout/public"); ?>  >Sign Out</a></span>
               <?php }
               else{?>
                    <span class="sgn-icon"><i class="fa fa-envelop-o"></i> <a href=<?php echo base_url("/home/org_public_web/frabi/register"); echo '/'.$compUrlShortName; ?>#register class="smoothScroll">Register</a></span>
                    <span class="sgn-icon"><i class="fa fa-envelop-o"></i> <a href=<?php echo base_url("/home/sign_in/pp"); ?>  >Sign In</a></span>
			
		    
               <?php }; ?>

			
                    </div>

               </div>
          </div>
     </header>


     <!-- MENU -->
     <section class="navbar navbar-default navbar-static-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE --> 
                    <img src=<?php echo base_url("/uploads/images/manipulated/thumbs"); echo "/" . $compLogo ?>  class="img-responsive" alt="">
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href=<?php echo base_url("/home/org_public_web/"); echo '/'.$compUrlShortName; ?> class="smoothScroll">Home</a></li>
                         <li><a href=<?php echo base_url("/home/org_public_web/"); echo '/'.$compUrlShortName; ?>#about class="smoothScroll">About Us</a></li>
                         
                         
                         <?php 
                         $row_counter = 1;
                         foreach($pages as $page) { 
                         ?>
                              <li><a href=<?php echo base_url("/home/org_public_web/"); echo '/'.$compUrlShortName; ?>/b/<?php echo $row_counter; ?> class="smoothScroll"><?php echo $page->pageName; ?></a></li>
                              
                         <?php 
                         $row_counter =  $row_counter +1;
                         } ?>
                         

                         <!--?php if (isset($pageName1))?-->
                              <!--li><a href="/home/org_public_pg1/<--?php echo '/'.$compUrlShortName; ?> class="smoothScroll"><--?php echo $pageName1; ?></a></li-->
                         


                         
                         
                       <li class="appointment-btn"><a href="<?php echo base_url("/home/org_public_web/") ;?>#appointment">Make an appointment</a></li>  
                    </ul>
               </div>

          </div>
     </section>