<!-- FOOTER -->
<footer data-stellar-background-ratio="5">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-4">
                         <div class="footer-thumb"> 
				<div class="opening-hours">
                                   <h4 class="wow fadeInUp" data-wow-delay="0.4s">Opening Hours</h4>
                                   <p><span><?php echo $compWorkingHrs; ?> </span></p>
                                   
                              </div> 

                              <h4 class="wow fadeInUp" data-wow-delay="0.4s">Contact Info</h4>
                             
                              <ul class="social-icon"><div class="contact-info">
				   
                                   <li><a href="<?php echo "mailto: ".$compEmail; ?>" class="fa fa-envelope-o"></a></li>
                                   
				   
				   

				   

                                   <!--li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li-->
                                   <li><a href="<?php echo "tel:" . $compPhoNumb; ?>" class="fa fa-phone"></a></li>

				   <li><a href="<?php echo "https://wa.me/" . $compWtzNumb ; ?>" target="_blank"class="fa fa-whatsapp" aria-hidden="true"></a></li>
				   <li><a href="<?php echo $twitter_acc; ?>" class="fa fa-twitter"></a></li>

                                   <li><a href="<?php echo $instgram_acc; ?>" class="fa fa-instagram"></a></li>  
				   <li><a href="<?php echo $snap_acc; ?>" class="fa fa-snapchat" aria-hidden="true"></a></li>  
                              </ul>
                       
                         </div>
                    </div>

                    

                    

<div class="col-md-8 col-sm-4"> 
                         <div class="footer-thumb"> 
<h4 class="wow fadeInUp" data-wow-delay="0.4s">Google location</h4>
				<section id="google-map">
     <!-- How to change your own map point
            1. Go to Google Maps
            2. Click on your location point
            3. Click "Share" and choose "Embed map" tab
            4. Copy only URL and paste it within the src="" field below
	-->
	  <iframe src="<?php echo $compLocation;?>" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
          <!--iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3647.3030413476204!2d100.5641230193719!3d13.757206847615207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf51ce6427b7918fc!2sG+Tower!5e0!3m2!1sen!2sth!4v1510722015945" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe-->
     </section>  

                              
                          </div>
                    </div>


                    <div class="col-md-12 col-sm-12 border-top">
                         <div class="col-md-4 col-sm-6">
                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2022 <?php echo $compPublicName; ?> </p>
                              </div>
                         </div>
                         <div class="col-md-6 col-sm-6">
                              <!--div class="footer-link"> 
                                   <a href="#">Laboratory Tests</a>
                                   <a href="#">Departments</a>
                                   <a href="#">Insurance Policy</a>
                                   <a href="#">Careers</a>
                              </div-->
                         </div>
                         <div class="col-md-2 col-sm-2 text-align-center">
                              <div class="angle-up-btn"> 
                                  <a href="#top" class="smoothScroll wow fadeInUp" data-wow-delay="1.2s"><i class="fa fa-angle-up"></i></a>
                              </div>
                         </div>   
                    </div>
                    
               </div>
          </div>
     </footer>

     <!-- SCRIPTS --> 
     <script src=<?php echo base_url("/js/jquery.js"); ?> ></script>
     <script src=<?php echo base_url("/js/bootstrap.min.js"); ?> ></script>
     <script src=<?php echo base_url("/js/jquery.sticky.js"); ?>     ></script>
     <script src=<?php echo base_url("/js/jquery.stellar.min.js"); ?>     ></script>
     <script src=<?php echo base_url("/js/wow.min.js"); ?>     ></script>
     <script src=<?php echo base_url("/js/smoothscroll.js"); ?>     ></script>
     <script src=<?php echo base_url("/js/owl.carousel.min.js"); ?>     ></script>
     <script src=<?php echo base_url("/js/custom.js"); ?>     ></script>

     





     <script>


function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  let expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function myFunction(a_day, a_mon, a_yer) {
     
     //window.open("http://localhost/home/org_public_web/"+a_yer);

    
    
     //var elem = document.getElementsByClassName('day_num');
     
     //alert(a_day);
     //alert(a_mon);
     //alert(a_yer);

     $('#myModal').modal('show').on('shown.bs.modal', function () {
        //$('.modal-day').html(a_day);
        var dayElement = document.querySelector('input[name="modal-day"]');
        dayElement.value = a_day;

        var dayElement = document.querySelector('input[name="modal-month"]');
        dayElement.value = a_mon;

        var dayElement = document.querySelector('input[name="modal-year"]');
        dayElement.value = a_yer;

        



        //setCookie("selected_day", a_day, "10");
        //setCookie("selected_month", a_mon, "10");
        //setCookie("selected_year", a_yer, "10");
        
       


        //$('.modal-month').html(a_mon);
        //$('.modal-year').html(a_yer);
    });

    




     

}


     </script>
</body>
</html>